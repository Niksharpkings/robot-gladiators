// Write code to print all numbers from 1 to `num`
// Assume `num` will be a positive number

var logNums = function(num) {
  for (var i = 1; i <= num; i++) {
    console.log(i);
  }
};
